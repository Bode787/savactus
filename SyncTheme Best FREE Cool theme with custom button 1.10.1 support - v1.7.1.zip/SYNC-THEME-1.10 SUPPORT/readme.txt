Tutorial:

1. Upload all files and folder in /var/www/pterodactyl

2. Run this commands (it may take some time):

curl -sL https://deb.nodesource.com/setup_14.x | sudo -E bash -
apt install -y nodejs
npm i -g yarn
cd /var/www/pterodactyl
yarn
yarn build:production
php artisan optimize

3. You are done, refresh your page!

If you need help or you find any bugs; errors dm me on discord: Dr.Ante#9085