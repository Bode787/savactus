<?php
$conn = new mysqli("localhost", "charlie", "charles21", "mglsi_news");
if($conn->connect_error){
    die("Erreur de connection");
}

?>  